package examples.ontology.ontologyServer;

import jade.content.AgentAction;

public class GetTime implements AgentAction {
}
